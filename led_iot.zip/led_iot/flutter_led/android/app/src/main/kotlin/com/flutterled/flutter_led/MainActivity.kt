package com.flutterled.flutter_led

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
